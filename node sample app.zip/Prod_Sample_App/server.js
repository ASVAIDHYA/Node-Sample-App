var http = require('http')
	fs = require('fs'),
	path = require('path'),
	url = require('url'),
	XLSX = require('xlsx');

//console.log(resultData);



http.createServer(function (request, response) {
    console.log('request starting...');	
	var filePath = '.' + request.url;
	var url_parts = url.parse(request.url);
	if (filePath == './')
		filePath = './index.html';
		
	var extname = path.extname(filePath);
	var contentType = 'text/html';
	switch (extname) {
		case '.js':
			contentType = 'text/javascript';
			break;
		case '.css':
			contentType = 'text/css';
			break;
		case '.png':
			contentType = 'image/png';
			break;
	}
	
	if (path) {
		console.log(filePath);
		if(filePath == './index.html'){
			fs.readFile(filePath, function(error, content) {
					if (error) {
						response.writeHead(500);
						response.end();
					}else {
						response.writeHead(200, { 'Content-Type': contentType });
						response.end(content, 'utf-8');	
					}
				});

		}else  if(filePath == './servers'){
		
			var workbook = XLSX.readFile('serverdetails.xlsx');
			var resultData = to_json(workbook);
			response.end(JSON.stringify(resultData));
		}else  if(filePath == './contacts'){
		
			var workbook = XLSX.readFile('contacts.xlsx');
			var resultData = to_json(workbook);
			response.end(JSON.stringify(resultData));
		}else  if(filePath == './serversTrail'){
		
			var workbook = XLSX.readFile('serverdetailsTrail.xlsx');
			var resultData = to_json(workbook);
			response.end(JSON.stringify(resultData));
		}else{
			fs.readFile(filePath, function(error, content) {
					if (error) {
						response.writeHead(500);
						response.end();
					}else {
						response.writeHead(200, { 'Content-Type': contentType });
						response.end(content, 'utf-8');	
					}
				});
		}

		
		
	}
	else {
		response.writeHead(404);
		response.end();
	}	
}).listen(8888);
console.log('Server running at http://localhost:8888/');

function to_json(workbook) {
    var result = {};
    workbook.SheetNames.forEach(function(sheetName) {
        var roa = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
        if(roa.length > 0){
            result[sheetName] = roa;
        }
    });
    return result;
}

























