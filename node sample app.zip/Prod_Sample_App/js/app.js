var tab = $(location).attr('pathname');

$(".top a").click(function(){
	$("html,body").animate({scrollTop:0},"slow");
	return false;
});

function to_json(workbook) {
    var result = {};
    workbook.SheetNames.forEach(function(sheetName) {
        var roa = XLSX.utils.sheet_to_row_object_array(workbook.Sheets[sheetName]);
        if(roa.length > 0){
            result[sheetName] = roa;
        }
    });
    return result;
};

if(tab=='/servers.html'){
	(function getServersData(){
			$.getJSON('/servers', function(result){
		    	var data = result;
		    	var id = 1;
		    	var elemTh='',elemTd='',elemData='';
		    	$.each(data, function( key, value ) {
				  var details=value;
				  for (var i=0, l = details.length; i < l;i++){
						 $.each(details[i], function (key,value){
						 		if(i<1){
						 			elemTh+='<th>'+key+'</th>';
						 		}
								elemTd+= '<td>'+value+'</td>';
						});
						 elemData+='<tr>'+elemTd+'</tr>';
						 elemTd ='';
				 	 }
				 	 elemData= "<div id='"+"tableData"+id+"'>"
				 	 			+"<div class='heading' onclick='toggleTable("+id+");'>"+"<span class='font23'>"+key+"</span><span class='iconMinus'></span></div>"
				 	 			+"<table class ='tg'><thead>"+elemTh+elemData+"</thead><tbody></tbody></div>";
				 	 id++;
				 	 $("#serversDiv").append(elemData);
				 	 elemData='',elemTh='';
				});
	    	});

	    })();
}else if(tab=='/contact.html'){
	(function getContacts(){
	    		$.getJSON('/contacts', function(result){
            	var data = result;
	    		$.each(data, function(key,value){
	    			var details=value;
	    			for(var i=0,l=details.length; i<l;i++){
	    				if(details[i].RoleID=='0'){
	    					var elem = '<div class="name"><b>'+details[i].Name+'</b></div>'+
									'<div class="name">'+details[i].Role+'</div>'+
									'<div><span class="iconM"></span><span class="mobileTxt">'+details[i].Mobile+'</span>'+
									'<span class="iconE"></span><span>'+details[i].Email+'</span></div>';
							$('#mainContact1').append(elem);			
	    				}
	    				if(details[i].RoleID=='1'){
	    					var elem = '<div class="name"><b>'+details[i].Name+'</b></div>'+
									'<div class="name">'+details[i].Role+'</div>'+
									'<div><span class="iconM"></span><span class="mobileTxt">'+details[i].Mobile+'</span>'+
									'<span class="iconE"></span><span>'+details[i].Email+'</span></div>';
							$('#mainContact2').append(elem);			
	    				}
	    				if(details[i].RoleID=='2'){
	    					var elem = '<div class="name">'+details[i].Name+'</div>'+
									'<div><span class="iconM"></span><span class="mobileTxt">'+details[i].Mobile+'</span>'+
									'<span class="iconE"></span><span>'+details[i].Email+'</span></div>';
							$('#amsTeam').append(elem);			
	    				}
	    				if(details[i].RoleID=='3'){
	    					var elem = '<div class="name">'+details[i].Name+'</div>'+
									'<div><span class="iconM"></span><span class="mobileTxt">'+details[i].Mobile+'</span>'+
									'<span class="iconE"></span><span>'+details[i].Email+'</span></div>';
							$('#otherTeam').append(elem);			
	    				}
	    			}
	    		});
	    	});

	    })();

}else{
	console.log('default');
};



function toggleTable(id){
	var divData = $("#tableData"+id).find('.heading').next();
	divData.toggle(function(){
		var spanData = $(this).prev().children('span')[1];
		if($(spanData).hasClass('iconMinus')){
			$(spanData).removeClass('iconMinus');
			$(spanData).addClass('iconPlus');
		}else{
			$(spanData).removeClass('iconPlus');
			$(spanData).addClass('iconMinus');
		}
	});
};

















